export const catagoryList = [
   [ 
        {
            title : 'ZARA ATHLETICZ',
            path : '/zara_athleticz',
            cName : 'styles.list'
        },
        {
            title : 'SUITS',
            path : '/suits',
            cName : 'styles.list'
        },
        {
            title : 'JEANS',
            path : '/jeans',
            cName : 'styles.list'
        },
        {
            title : 'SHIRT',
            path : '/shirt',
            cName : 'styles.list'
        }
    ],
    [ 
        {
            title : 'SKIRTS',
            path : '/skirts',
            cName : 'styles.list'
        },
        {
            title : 'TOPS | CORSETS',
            path : '/tops_corsets',
            cName : 'styles.list'
        },
        {
            title : 'BLAZERS',
            path : '/blazers',
            cName : 'styles.list'
        },
        {
            title : 'SHIRTS | BLOUSES',
            path : '/shirt_blouses',
            cName : 'styles.list'
        }
    ],
    [ 
      
        {
            title : 'GIRL | 6-14 YEARS',
            path : '/girl_6_to_14',
            cName : 'styles.list'
        },
        {
            title : 'BOY | 6-14 YEARS',
            path : '/boy_6_to_14',
            cName : 'styles.list'
        },
        {
            title : 'HOME KIDS',
            path : '/home_kids',
            cName : 'styles.list'
        }
    ],
]