// import React from 'react'
// import { useSelector,useDispatch } from "react-redux";
// import { getTshirtData } from '../Redux/AppProvider/action';
// import { useEffect } from 'react';
// import styled from 'styled-components';
// import SProductCard from '../Components/SProductCard';

// const StrackSuit = () => {
//     const TRACKSUITS=useSelector(state=>state.AppReducer.StrackSuit)
//     const dispatch=useDispatch();
//     console.log(StrackSuit)
//   return (
//     <div>StrackSuit</div>
//   )
// }

// export default StrackSuit