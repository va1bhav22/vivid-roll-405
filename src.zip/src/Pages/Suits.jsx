import React from 'react'

const Suits = () => {
  return (
    <div>Suits</div>
  )
}

export default Suits