import React from 'react'

const Blazers = () => {
  return (
    <div>Blazers</div>
  )
}

export default Blazers