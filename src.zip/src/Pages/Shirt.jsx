import React from 'react'

const Shirt = () => {
  return (
    <div>Shirt</div>
  )
}

export default Shirt
