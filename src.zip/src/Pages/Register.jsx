import React from 'react'
import styles from '../Styled/login.module.css';

const Register = () => {
  return (
    <div>
        <p>Don't have Account </p>
        <p className={styles.heading}>REGISTER</p>
    </div>
  )
}

export default Register