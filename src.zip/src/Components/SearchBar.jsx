import React from 'react'

const SearchBar = () => {
  return (
    <div>SearchBar</div>
  )
}

export default SearchBar